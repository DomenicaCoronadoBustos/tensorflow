![image](https://github.com/DomenicaCoronadoBustos/RECONOCIMIENTO/assets/153152552/ebdc2cb2-21e5-4407-9052-162d4fa8678f)
